# Prompt Denetçisi

Başlıca AI sitelerinde (ChatGPT, Claude.ai, Gemini, Perplexity, Grok) yazdığın
**ilk prompt'u** eksiksiz ve doğru hale getirir. Kendi Anthropic API anahtarınla
çalışır — hiçbir veri Anthropic dışında bir sunucuya gönderilmez.

## Özellikler

### 1) Canlı Belirsizlik Göstergesi
Yazarken (henüz göndermeden) input kutusunun üstünde küçük bir çubuk belirir:
prompt'un ne kadar "net" olduğunu gösterir (Net / Geliştirilebilir / Belirsiz).
Bu tamamen yerel, basit kurallarla çalışır — API çağrısı yapmaz, maliyetsizdir.

### 2) Görev Tipine Göre İyileştirme (Ctrl+Enter)
Ctrl+Enter'a bastığında uzantı prompt'unun türünü (kod yazma, yazılı içerik,
analiz, çeviri, tasarım, planlama vb.) otomatik tanır ve o türe özgü, cevap
kalitesini artıracak yapısal talimatları prompt'un içine kendiliğinden ekler.
Onay penceresinin üstünde hangi tür olarak algılandığı rozet ile gösterilir.

### 3) Eksik Bilgi İşaretleme
Cevap için gerekli olabilecek ama senin belirtmediğin bilgiler (hedef kitle,
format, dil/versiyon, ton, kapsam gibi) **köşeli parantez** ile, sarı vurgulu
olarak işaretlenir. Örnek:

> "Bana [hangi amaçla: portföy/e-ticaret/blog] bir web sitesi yap.
> [Hangi teknoloji?] kullan."

### 4) Tek Tıkla Takip Soruları
Tespit edilen en önemli eksiklikler için, model otomatik olarak kısa çoktan
seçmeli sorular üretir. Bunlara yazı yazmana gerek yok — bir seçeneğe
tıklarsın, ilgili köşeli parantez otomatik o cevapla değişir.

### 5) Kullanım İstatistikleri
Onay penceresinin altında bu isteğin ve toplam kullanımın token sayısı
gösterilir. Ayarlar sayfasında toplam istem/token kartları ve "Sıfırla"
butonu bulunur. Tüm veriler yalnızca senin cihazında tutulur.

## Desteklenen Siteler

- ChatGPT (chat.openai.com, chatgpt.com)
- Claude.ai
- Gemini (gemini.google.com)
- Perplexity (perplexity.ai)
- Grok (grok.com)

Not: Bu sitelerin arayüzü zaman zaman değişebiliyor. Bir sitede input veya
gönder butonu bulunamazsa, `content.js` içindeki `INPUT_SELECTORS` /
`SEND_BUTTON_SELECTORS` listelerine o sitenin güncel seçicisi eklenmeli.

## Nasıl Kurulur (test / kişisel kullanım)

1. Chrome'da `chrome://extensions` adresine git.
2. Sağ üstten **Geliştirici modu**'nu aç.
3. **Paketlenmemiş öğe yükle** (Load unpacked) butonuna tıkla.
4. Bu klasörü (`prompt-denetci`) seç.
5. Uzantı ikonuna tıkla, Anthropic API anahtarını gir, Kaydet'e bas.

⚠️ API anahtarını **console.anthropic.com/settings/keys** üzerinden alırken,
mutlaka bir **workspace seçili** olarak oluştur. Workspace'siz anahtarlar
"not scoped to a workspace" hatası verir.

## Nasıl Kullanılır

1. Herhangi bir desteklenen sitede promptunu yaz. Yazarken üstte beliren
   çubuk, ne kadar net olduğunu anlık gösterir.
2. Normal **Enter** ile gönderirsen hiçbir şey değişmez — uzantı karışmaz.
3. **Ctrl+Enter** (Mac'te Cmd+Enter) basarsan:
   - Uzantı yazdığın metni analiz eder, görev tipini tanır, eksik bilgileri
     tespit eder.
   - Onay penceresi açılır: görev tipi rozeti, sarı vurgulu köşeli parantezli
     notlar ve varsa tek tıkla cevaplanabilir takip soruları gösterilir.
   - Soruları cevapla veya metni elle düzenle, **Gönder**'e bas.
   - **İptal** dersen (veya pencere dışına tıklarsan / Esc'e basarsan) hiçbir
     şey gönderilmez.

## Ayarlar

Uzantı ikonuna tıklayarak:
- API anahtarını değiştirebilirsin.
- Model seçebilirsin (Haiku = hızlı/ucuz, Sonnet = daha güçlü).
- Uzantıyı tamamen kapatabilirsin.
- Kullanım istatistiklerini görüp sıfırlayabilirsin.

## Maliyet

**BYOK (Bring Your Own Key)** modeliyle çalışır: her Ctrl+Enter isteği senin
kendi Anthropic API anahtarınla ücretlendirilir. Canlı belirsizlik göstergesi
API çağrısı yapmaz, tamamen ücretsizdir. Geliştirici hiçbir kullanım verisi
görmez veya saklamaz.

## Bilinen Sınırlamalar (v1.3.0)

- Bu araç prompt mühendisliğini tamamen ortadan kaldırmaz — problemi doğru
  tanımlamak, karmaşık görevlerde iteratif düzeltme yapmak hâlâ kullanıcı
  kararı gerektirir. Uzantı, ilk prompt'u eksiksiz hale getirme sürecini
  büyük ölçüde otomatikleştirir.
- Site arayüzleri değiştikçe seçiciler güncellenmeli.
- API anahtarı tarayıcının yerel depolamasında düz metin olarak tutulur.
- İstatistikler yalnızca bu tarayıcı profilinde tutulur.
