(function () {
  'use strict';

  let isProcessing = false;

  // --- Site bazlı seçiciler: her site için birkaç yedek seçici deneriz ---
  const INPUT_SELECTORS = [
    '#prompt-textarea',                                   // ChatGPT
    'div[contenteditable="true"][data-testid*="chat" i]',
    'div.ProseMirror[contenteditable="true"]',             // Claude.ai
    'rich-textarea div[contenteditable="true"]',           // Gemini
    'textarea[placeholder*="Ask" i]',                      // Perplexity / Grok vb.
    'textarea[data-testid="tweetTextarea_0"]',
    'form textarea',
    'div[contenteditable="true"]'
  ];

  const SEND_BUTTON_SELECTORS = [
    'button[data-testid="send-button"]',                   // ChatGPT
    'button[aria-label*="Send" i]',
    'button[aria-label*="Gönder" i]',
    'button[aria-label*="Submit" i]',
    'button[type="submit"]'
  ];

  function findInputElement() {
    for (const sel of INPUT_SELECTORS) {
      const el = document.querySelector(sel);
      if (el && isVisible(el)) return el;
    }
    return null;
  }

  function findSendButton() {
    for (const sel of SEND_BUTTON_SELECTORS) {
      const el = document.querySelector(sel);
      if (el && isVisible(el) && !el.disabled) return el;
    }
    return null;
  }

  function isVisible(el) {
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function getText(el) {
    if (!el) return '';
    if (el.tagName === 'TEXTAREA') return el.value;
    return el.innerText || el.textContent || '';
  }

  function setText(el, text) {
    if (!el) return;
    if (el.tagName === 'TEXTAREA') {
      const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
      setter.call(el, text);
      el.dispatchEvent(new Event('input', { bubbles: true }));
    } else {
      el.focus();
      document.execCommand('selectAll', false, null);
      document.execCommand('insertText', false, text);
      el.dispatchEvent(new Event('input', { bubbles: true }));
    }
  }

  function submitForm(inputEl) {
    const sendBtn = findSendButton();
    if (sendBtn) {
      sendBtn.click();
      return;
    }
    inputEl.dispatchEvent(new KeyboardEvent('keydown', {
      key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true
    }));
  }

  // --- Küçük durum bildirimi (toast) ---
  function showToast(message, type = 'info') {
    let toast = document.getElementById('pd-toast');
    if (toast) toast.remove();

    toast = document.createElement('div');
    toast.id = 'pd-toast';
    toast.className = `pd-toast pd-toast-${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);

    requestAnimationFrame(() => toast.classList.add('pd-toast-visible'));

    setTimeout(() => {
      toast.classList.remove('pd-toast-visible');
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }

  // --- Köşeli parantez tespiti: [...] içindeki notları say ve HTML olarak vurgula ---
  const BRACKET_REGEX = /\[([^\[\]]+)\]/g;

  function countBrackets(text) {
    const matches = text.match(BRACKET_REGEX);
    return matches ? matches.length : 0;
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  function renderHighlightedHtml(text) {
    const escaped = escapeHtml(text);
    return escaped.replace(/\[([^\[\]]+)\]/g, '<mark class="pd-bracket">[$1]</mark>');
  }

  function formatNumber(n) {
    return new Intl.NumberFormat('tr-TR').format(n);
  }

  // ================= Canlı Belirsizlik Skoru (kural tabanlı, API çağrısı yok) =================
  // Basit sezgisel kurallar: kısa metin, soru işareti yok, belirsiz kelimeler, format/bağlam eksikliği.
  const VAGUE_WORDS = [
    'bir şey', 'bişey', 'güzel', 'iyi bir', 'yardım et', 'yap bana', 'nasıl yapılır',
    'anlat', 'bilgi ver', 'şey', 'falan', 'filan'
  ];

  function computeVaguenessScore(text) {
    const trimmed = text.trim();
    if (!trimmed) return null;

    const wordCount = trimmed.split(/\s+/).filter(Boolean).length;
    let score = 0; // 0 = çok net, 100 = çok belirsiz

    // Kısa promptlar genelde daha belirsizdir
    if (wordCount < 4) score += 45;
    else if (wordCount < 8) score += 25;
    else if (wordCount < 15) score += 10;

    // Belirsiz kalıp kelimeler
    const lower = trimmed.toLowerCase();
    let vagueHits = 0;
    for (const w of VAGUE_WORDS) {
      if (lower.includes(w)) vagueHits++;
    }
    score += Math.min(vagueHits * 12, 30);

    // Hiç sayı, tarih, format, dil/versiyon belirtisi yoksa hafif ekle
    const hasSpecificMarkers = /\d|https?:\/\/|\.js|\.py|python|javascript|react|excel|word|pdf/i.test(trimmed);
    if (!hasSpecificMarkers && wordCount < 20) score += 10;

    // Çok soru işareti veya "?" ile bitmeyen tek cümlelik emir kipi -> hafif belirsizlik
    if (wordCount >= 20) score = Math.max(score - 15, 0);

    return Math.max(0, Math.min(100, score));
  }

  function getVaguenessLabel(score) {
    if (score === null) return { label: '', className: '' };
    if (score >= 55) return { label: 'Belirsiz', className: 'pd-vague-high' };
    if (score >= 25) return { label: 'Geliştirilebilir', className: 'pd-vague-mid' };
    return { label: 'Net', className: 'pd-vague-low' };
  }

  function ensureVaguenessBadge(inputEl) {
    let badge = document.getElementById('pd-vague-badge');
    if (badge) return badge;

    badge = document.createElement('div');
    badge.id = 'pd-vague-badge';
    badge.className = 'pd-vague-badge';
    badge.innerHTML = `
      <div class="pd-vague-bar-track"><div class="pd-vague-bar-fill" id="pd-vague-fill"></div></div>
      <span class="pd-vague-text" id="pd-vague-text"></span>
    `;
    document.body.appendChild(badge);
    return badge;
  }

  function positionBadgeNearInput(badge, inputEl) {
    const rect = inputEl.getBoundingClientRect();
    badge.style.position = 'fixed';
    badge.style.left = `${rect.left}px`;
    badge.style.top = `${Math.max(rect.top - 34, 8)}px`;
    badge.style.width = `${Math.min(rect.width, 260)}px`;
  }

  function updateVaguenessIndicator() {
    const inputEl = findInputElement();
    const badge = document.getElementById('pd-vague-badge');
    if (!inputEl) {
      if (badge) badge.style.display = 'none';
      return;
    }
    const text = getText(inputEl).trim();
    if (!text) {
      if (badge) badge.style.display = 'none';
      return;
    }

    const score = computeVaguenessScore(text);
    const { label, className } = getVaguenessLabel(score);
    const el = ensureVaguenessBadge(inputEl);
    positionBadgeNearInput(el, inputEl);
    el.style.display = 'flex';
    el.className = `pd-vague-badge ${className}`;

    const fill = document.getElementById('pd-vague-fill');
    const textEl = document.getElementById('pd-vague-text');
    if (fill) fill.style.width = `${score}%`;
    if (textEl) textEl.textContent = label;
  }

  // Yazarken canlı güncelle (debounce ile, performans için)
  let debounceTimer = null;
  document.addEventListener('input', () => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(updateVaguenessIndicator, 150);
  }, true);

  window.addEventListener('scroll', updateVaguenessIndicator, true);
  window.addEventListener('resize', updateVaguenessIndicator);

  chrome.storage.local.get(['enabled'], (data) => {
    if (data.enabled !== false) {
      setInterval(updateVaguenessIndicator, 1500); // sayfa değişimlerini de yakalasın
    }
  });

  // ================= Görev türü rozeti metni =================
  const TASK_TYPE_LABELS = {
    'kod yazma': '💻 Kod',
    'yazılı içerik': '✍️ Yazı',
    'analiz/araştırma': '🔍 Analiz',
    'çeviri': '🌐 Çeviri',
    'tasarım/görsel': '🎨 Tasarım',
    'veri/tablo': '📊 Veri',
    'planlama': '🗓️ Planlama',
    'genel soru-cevap': '💬 Soru-Cevap',
    'diğer': '✦ Genel'
  };

  // ================= Onay pop-up'ı =================
  function showReviewModal(improvedText, taskType, quickQuestions, statsInfo, onConfirm, onCancel) {
    const existing = document.getElementById('pd-modal-overlay');
    if (existing) existing.remove();

    const bracketCount = countBrackets(improvedText);
    const taskLabel = TASK_TYPE_LABELS[taskType] || TASK_TYPE_LABELS['diğer'];

    const overlay = document.createElement('div');
    overlay.id = 'pd-modal-overlay';
    overlay.className = 'pd-modal-overlay';

    const modal = document.createElement('div');
    modal.className = 'pd-modal';

    // Header
    const header = document.createElement('div');
    header.className = 'pd-modal-header';

    const headerLeft = document.createElement('div');
    headerLeft.className = 'pd-modal-header-left';
    const icon = document.createElement('div');
    icon.className = 'pd-modal-icon';
    icon.textContent = '✦';
    const titleWrap = document.createElement('div');
    const titleRow = document.createElement('div');
    titleRow.style.display = 'flex';
    titleRow.style.alignItems = 'center';
    titleRow.style.gap = '8px';
    const title = document.createElement('div');
    title.className = 'pd-modal-title';
    title.textContent = 'Prompt Denetçisi';
    const taskBadge = document.createElement('span');
    taskBadge.className = 'pd-task-badge';
    taskBadge.textContent = taskLabel;
    titleRow.appendChild(title);
    titleRow.appendChild(taskBadge);
    const subtitle = document.createElement('div');
    subtitle.className = 'pd-modal-subtitle';
    subtitle.textContent = bracketCount > 0
      ? `${bracketCount} alan tamamlamanı bekliyor`
      : 'Prompt hazır, doğrudan gönderebilirsin';
    titleWrap.appendChild(titleRow);
    titleWrap.appendChild(subtitle);
    headerLeft.appendChild(icon);
    headerLeft.appendChild(titleWrap);

    const closeBtn = document.createElement('button');
    closeBtn.className = 'pd-modal-close';
    closeBtn.textContent = '✕';
    closeBtn.onclick = () => { overlay.remove(); onCancel(); };

    header.appendChild(headerLeft);
    header.appendChild(closeBtn);

    // Editable preview
    const editorWrap = document.createElement('div');
    editorWrap.className = 'pd-editor-wrap';

    const editor = document.createElement('div');
    editor.className = 'pd-modal-editor';
    editor.contentEditable = 'true';
    editor.innerHTML = renderHighlightedHtml(improvedText);

    editorWrap.appendChild(editor);

    // Hızlı takip soruları (tıklanabilir seçenekler)
    let questionsBlock = null;
    if (quickQuestions && quickQuestions.length > 0) {
      questionsBlock = document.createElement('div');
      questionsBlock.className = 'pd-questions-block';

      const qTitle = document.createElement('div');
      qTitle.className = 'pd-questions-title';
      qTitle.textContent = 'Hızlı yanıtla, prompt otomatik güncellensin:';
      questionsBlock.appendChild(qTitle);

      quickQuestions.forEach((q) => {
        const qRow = document.createElement('div');
        qRow.className = 'pd-question-row';

        const qText = document.createElement('div');
        qText.className = 'pd-question-text';
        qText.textContent = q.question;
        qRow.appendChild(qText);

        const optRow = document.createElement('div');
        optRow.className = 'pd-question-options';

        (q.options || []).forEach((opt) => {
          const optBtn = document.createElement('button');
          optBtn.className = 'pd-option-btn';
          optBtn.textContent = opt;
          optBtn.onclick = () => {
            // İlk eşleşen köşeli parantezi bu cevapla değiştir
            const currentHtml = editor.innerHTML;
            const currentText = editor.innerText;
            const bracketMatch = currentText.match(BRACKET_REGEX);
            if (bracketMatch && bracketMatch.length > 0) {
              const newText = currentText.replace(BRACKET_REGEX, (m, inner, offset, full) => {
                // Sadece ilk eşleşmeyi değiştir
                if (full.indexOf(m) === offset) return opt;
                return m;
              });
              // İlk eşleşmeyi manuel bul ve değiştir (replace yukarıdaki tüm eşleşmeleri denemesin diye)
              const firstMatch = currentText.match(BRACKET_REGEX)[0];
              const replaced = currentText.replace(firstMatch, opt);
              editor.innerHTML = renderHighlightedHtml(replaced);
            }
            optBtn.classList.add('pd-option-selected');
            qRow.querySelectorAll('.pd-option-btn').forEach(b => {
              if (b !== optBtn) b.disabled = true;
            });
          };
          optRow.appendChild(optBtn);
        });

        qRow.appendChild(optRow);
        questionsBlock.appendChild(qRow);
      });
    }

    // Bracket bilgi çubuğu
    let bracketNotice = null;
    if (bracketCount > 0 && (!quickQuestions || quickQuestions.length === 0)) {
      bracketNotice = document.createElement('div');
      bracketNotice.className = 'pd-bracket-notice';
      bracketNotice.innerHTML = `<span class="pd-bracket-dot"></span> Sarı işaretli <b>${bracketCount}</b> yeri doldurup göndermen, daha isabetli bir cevap almanı sağlar.`;
    }

    // İstatistik çubuğu
    const statsBar = document.createElement('div');
    statsBar.className = 'pd-stats-bar';
    statsBar.innerHTML = `
      <div class="pd-stat"><span class="pd-stat-label">Bu istek</span><span class="pd-stat-value">${formatNumber(statsInfo.lastInputTokens + statsInfo.lastOutputTokens)} token</span></div>
      <div class="pd-stat-sep"></div>
      <div class="pd-stat"><span class="pd-stat-label">Toplam istem</span><span class="pd-stat-value">${formatNumber(statsInfo.totalRequests)}</span></div>
      <div class="pd-stat-sep"></div>
      <div class="pd-stat"><span class="pd-stat-label">Toplam token</span><span class="pd-stat-value">${formatNumber(statsInfo.totalInputTokens + statsInfo.totalOutputTokens)}</span></div>
    `;

    const btnRow = document.createElement('div');
    btnRow.className = 'pd-modal-btn-row';

    const cancelBtn = document.createElement('button');
    cancelBtn.className = 'pd-btn pd-btn-cancel';
    cancelBtn.textContent = 'İptal';
    cancelBtn.onclick = () => {
      overlay.remove();
      onCancel();
    };

    const confirmBtn = document.createElement('button');
    confirmBtn.className = 'pd-btn pd-btn-confirm';
    confirmBtn.textContent = 'Gönder';
    confirmBtn.onclick = () => {
      const finalText = editor.innerText;
      overlay.remove();
      onConfirm(finalText);
    };

    btnRow.appendChild(cancelBtn);
    btnRow.appendChild(confirmBtn);

    modal.appendChild(header);
    modal.appendChild(editorWrap);
    if (questionsBlock) modal.appendChild(questionsBlock);
    if (bracketNotice) modal.appendChild(bracketNotice);
    modal.appendChild(statsBar);
    modal.appendChild(btnRow);
    overlay.appendChild(modal);
    document.body.appendChild(overlay);

    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) {
        overlay.remove();
        onCancel();
      }
    });

    const escHandler = (e) => {
      if (e.key === 'Escape') {
        overlay.remove();
        document.removeEventListener('keydown', escHandler);
        onCancel();
      }
    };
    document.addEventListener('keydown', escHandler);

    editor.focus();
    const range = document.createRange();
    range.selectNodeContents(editor);
    range.collapse(false);
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
  }

  async function handleImproveAndReview(inputEl) {
    if (isProcessing) return;
    const rawText = getText(inputEl).trim();
    if (!rawText) return;

    isProcessing = true;
    showToast('✦ Prompt analiz ediliyor...', 'loading');

    chrome.runtime.sendMessage(
      { type: 'IMPROVE_PROMPT', text: rawText },
      (response) => {
        isProcessing = false;
        if (!response) {
          showToast('Uzantı ile bağlantı kurulamadı.', 'error');
          return;
        }
        if (!response.ok) {
          showToast('Hata: ' + response.error, 'error');
          return;
        }

        const stats = response.stats || {};
        const statsInfo = {
          lastInputTokens: response.inputTokens || 0,
          lastOutputTokens: response.outputTokens || 0,
          totalRequests: stats.totalRequests || 0,
          totalInputTokens: stats.totalInputTokens || 0,
          totalOutputTokens: stats.totalOutputTokens || 0
        };

        showReviewModal(
          response.improved,
          response.taskType,
          response.quickQuestions,
          statsInfo,
          (finalText) => {
            setText(inputEl, finalText);
            setTimeout(() => submitForm(inputEl), 150);
          },
          () => {
            showToast('İptal edildi', 'info');
          }
        );
      }
    );
  }

  function onKeyDown(e) {
    const isCtrlEnter = (e.ctrlKey || e.metaKey) && e.key === 'Enter';
    if (!isCtrlEnter) return;

    const inputEl = findInputElement();
    if (!inputEl) return;

    e.preventDefault();
    e.stopPropagation();

    chrome.storage.local.get(['enabled'], (data) => {
      if (data.enabled === false) {
        submitForm(inputEl);
        return;
      }
      handleImproveAndReview(inputEl);
    });
  }

  document.addEventListener('keydown', onKeyDown, true);

  console.log('[Prompt Denetçisi] Aktif. Ctrl+Enter ile promptunu kontrol ettir.');
})();
