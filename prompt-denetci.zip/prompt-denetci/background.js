const SYSTEM_PROMPT = `Sen, kullanıcıların yapay zekaya verdiği İLK prompt'u eksiksiz ve doğru hale getiren bir uzmansın.
Bu araç genelde bir konuşmanın İLK mesajında kullanılır: yani sistemin kullanıcıyı, ihtiyacını ve bağlamı
henüz hiç tanımadığı an. Amacın, prompt'u sadece "daha akıcı" yazmak değil; sistemin doğru cevap üretebilmesi
için gereken TÜM bilgiyi prompt'un içine yerleştirmek veya eksik olan yerleri açıkça işaretlemektir.

ADIM 1 — Görev türünü tanı: Prompt'un hangi kategoriye girdiğini belirle (kod yazma, yazılı içerik,
analiz/araştırma, çeviri, tasarım/görsel, veri/tablo, genel soru-cevap, planlama, diğer). Bu kategoriye
özgü, cevap kalitesini gerçekten artıracak yapısal talimatları (biçim, adım adım düşünme, örnek verme gibi)
prompt'un içine kendiliğinden ekle — kullanıcıya bunu ayrıca sorma, sen kendin uygula. Örnekler:
- Kod yazma → hangi dil/versiyon belirtilmemişse köşeli parantezle sor; "çalışan, yorum satırlı kod" gibi
  bir beklenti henüz yoksa ekle.
- Yazılı içerik (makale, e-posta, mesaj) → ton, uzunluk, hedef kitle belirtilmemişse köşeli parantezle sor.
- Analiz/araştırma → hangi kaynaklara/verilere dayanılacağı, ne kadar derinlikte isteniyor, belirtilmemişse sor.
- Tasarım/görsel → stil, renk, kullanım amacı belirtilmemişse sor.
- Planlama → zaman aralığı, kısıtlar (bütçe, kişi sayısı vb.) belirtilmemişse sor.

ADIM 2 — Eksik bilgiyi işaretle: Cevap için gerekli olabilecek ama kullanıcının BELİRTMEDİĞİ bilgileri
tespit et. Bu eksik yerleri prompt'un içine, tam ait olduğu noktaya köşeli parantez içinde ekle.
Örnek: "[hedef kitleyi belirt: örn. çocuklar/yetişkinler]" veya "[hangi programlama dili?]".
Notlar kısa, somut ve tek bakışta doldurulabilir olmalı. Genel/anlamsız notlar ekleme
("[daha fazla detay ver]" gibi) — sadece cevabın kalitesini gerçekten etkileyecek eksiklikleri işaretle.
E�er prompt zaten yeterince net ve eksiksizse, hiç köşeli parantez ekleme.

ADIM 3 — Hızlı takip soruları üret: Köşeli parantezle işaretlediğin eksikliklerden en önemli olan
en fazla 3 tanesi için, kullanıcının TEK TIKLA cevaplayabileceği kısa çoktan seçmeli sorular hazırla.
Her soru için 2-4 kısa seçenek üret (birkaç kelime, buton üzerinde gösterilecek). Eğer köşeli parantez
yoksa (prompt zaten eksiksizse) bu listeyi boş bırak.

Genel kurallar:
- Kullanıcının niyetini koru, asla değiştirme.
- Gereksiz nezaket kelimeleri ekleme, doğrudan ve verimli yaz.
- Kullanıcının kullandığı dili koru (Türkçe ise Türkçe, İngilizce ise İngilizce yaz).

ÇIKTI FORMATI — SADECE aşağıdaki JSON şemasına uyan, başka hiçbir şey içermeyen bir JSON döndür.
Açıklama, markdown code fence (\`\`\`), giriş cümlesi EKLEME. Sadece ham JSON:

{
  "task_type": "kod yazma" | "yazılı içerik" | "analiz/araştırma" | "çeviri" | "tasarım/görsel" | "veri/tablo" | "planlama" | "genel soru-cevap" | "diğer",
  "improved_prompt": "köşeli parantezli notlarla zenginleştirilmiş, iyileştirilmiş prompt metni",
  "quick_questions": [
    { "question": "kısa soru metni", "options": ["seçenek1", "seçenek2", "seçenek3"] }
  ]
}`;

async function improvePrompt(rawPrompt, apiKey, model) {
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
      'anthropic-dangerous-direct-browser-access': 'true'
    },
    body: JSON.stringify({
      model: model || 'claude-haiku-4-5-20251001',
      max_tokens: 1024,
      system: SYSTEM_PROMPT,
      messages: [
        { role: 'user', content: rawPrompt }
      ]
    })
  });

  if (!response.ok) {
    const errText = await response.text();
    if (errText.includes('not scoped to a workspace')) {
      throw new Error('Bu API anahtarı bir workspace\'e bağlı değil. console.anthropic.com/settings/keys üzerinden, workspace seçili şekilde YENİ bir anahtar oluşturup onu kullan.');
    }
    if (response.status === 401) {
      throw new Error('API anahtarı geçersiz. Ayarlardan doğru anahtarı girdiğinden emin ol.');
    }
    if (response.status === 429) {
      throw new Error('API kullanım limitine ulaşıldı. Birkaç dakika sonra tekrar dene.');
    }
    throw new Error(`API hatası (${response.status}): ${errText}`);
  }

  const data = await response.json();
  const textBlock = data.content.find(b => b.type === 'text');
  if (!textBlock) throw new Error('Model metin döndürmedi.');

  const usage = data.usage || {};
  let parsed;
  try {
    // Model bazen kod bloğu içine sarabilir, temizle
    const cleaned = textBlock.text.trim().replace(/^```json\s*|^```\s*|```\s*$/g, '');
    parsed = JSON.parse(cleaned);
  } catch (e) {
    // JSON parse başarısızsa, düz metni improved_prompt olarak kullan (geriye dönük güvenlik)
    parsed = { task_type: 'diğer', improved_prompt: textBlock.text.trim(), quick_questions: [] };
  }

  return {
    improved: parsed.improved_prompt || '',
    taskType: parsed.task_type || 'diğer',
    quickQuestions: Array.isArray(parsed.quick_questions) ? parsed.quick_questions : [],
    inputTokens: usage.input_tokens || 0,
    outputTokens: usage.output_tokens || 0
  };
}

async function recordUsage(inputTokens, outputTokens) {
  const data = await chrome.storage.local.get(['stats']);
  const stats = data.stats || { totalRequests: 0, totalInputTokens: 0, totalOutputTokens: 0 };
  stats.totalRequests += 1;
  stats.totalInputTokens += inputTokens;
  stats.totalOutputTokens += outputTokens;
  await chrome.storage.local.set({ stats });
  return stats;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'IMPROVE_PROMPT') {
    chrome.storage.local.get(['apiKey', 'model'], async (data) => {
      if (!data.apiKey) {
        sendResponse({ ok: false, error: 'API anahtarı ayarlanmamış. Uzantı ikonuna tıklayıp ayarlardan gir.' });
        return;
      }
      try {
        const result = await improvePrompt(message.text, data.apiKey, data.model);
        const stats = await recordUsage(result.inputTokens, result.outputTokens);
        sendResponse({
          ok: true,
          improved: result.improved,
          taskType: result.taskType,
          quickQuestions: result.quickQuestions,
          inputTokens: result.inputTokens,
          outputTokens: result.outputTokens,
          stats
        });
      } catch (err) {
        sendResponse({ ok: false, error: err.message });
      }
    });
    return true; // async response için gerekli
  }

  if (message.type === 'GET_STATS') {
    chrome.storage.local.get(['stats'], (data) => {
      sendResponse({ ok: true, stats: data.stats || { totalRequests: 0, totalInputTokens: 0, totalOutputTokens: 0 } });
    });
    return true;
  }

  if (message.type === 'RESET_STATS') {
    chrome.storage.local.set({ stats: { totalRequests: 0, totalInputTokens: 0, totalOutputTokens: 0 } }, () => {
      sendResponse({ ok: true });
    });
    return true;
  }
});
